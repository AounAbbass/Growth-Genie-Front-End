import React from 'react'

const ContentInspiration = () => {
  return (
    <div>ContentInspiration</div>
  )
}

export default ContentInspiration